
import UIKit

class ViewContactController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var instegramLabel: UILabel!
    @IBOutlet weak var twitterLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    
    var model = contact()
    override func viewDidLoad() {
        super.viewDidLoad()

        if model != nil {
            nameLabel.text = model.name
            mobileLabel.text = model.mobile
            twitterLabel.text = model.twitter
            instegramLabel.text = model.instegram
        }
      
    }
    

    @IBAction func btnBack(_ sender: Any) {
        let next = self.storyboard?.instantiateViewController(withIdentifier: "Home") as! ViewController
        next.modalPresentationStyle = .fullScreen
       
        self.present(next, animated: true, completion: nil)
    }
    
}
