
import UIKit
import FirebaseDatabase
class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var myContacts = [contact]()
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        getData()
    }

    @IBAction func btnAdd(_ sender: Any) {
        let next = self.storyboard?.instantiateViewController(withIdentifier: "AddContact") as! AddContactViewController
        next.modalPresentationStyle = .fullScreen
       
        self.present(next, animated: true, completion: nil)
        
    }
    func getData( )
    {
        Database.database().reference().child("Contacts").getData { errorData, snapShot in
            
            if errorData != nil
            {
                print(errorData!.localizedDescription)
                
            }
            if (snapShot!.exists()) {
                for (_ , val) in snapShot?.value as! NSDictionary {
                    var mContact = contact()
                    let value = val as! NSDictionary
                    mContact.Id = value["Id"] as! String
                    mContact.name = value["name"] as! String
                    mContact.mobile = value["mobile"] as! String
                    mContact.instegram = value["instegram"] as! String
                    mContact.twitter = value["twitter"] as! String
                    self.myContacts.append(mContact)
                }
                self.tableView.reloadData()
            }
        }
    }

}

extension ViewController : UITableViewDataSource
{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.phoneLabel.text = self.myContacts[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.myContacts.count
    }
}
extension ViewController : UITableViewDelegate
{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let next = self.storyboard?.instantiateViewController(withIdentifier: "ViewContact") as! ViewContactController
        next.modalPresentationStyle = .fullScreen
        next.model = self.myContacts[indexPath.row]
        self.present(next, animated: true, completion: nil)
    }
}
