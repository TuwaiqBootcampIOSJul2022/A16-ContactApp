
import UIKit
import FirebaseDatabase
class AddContactViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var instegram: UITextField!
    @IBOutlet weak var twitter: UITextField!
    @IBOutlet weak var mobile: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func btnSave(_ sender: UIButton) {
       guard let name = name.text,
        let mobileNumber = mobile.text,
        let instegramAccount = instegram.text,
        let twitterAccount = twitter.text else
        {
            print("error in getting data")
            return
        }
        
        let db = Database.database().reference()
        let uuid = UUID().uuidString
        let myContact = contact(Id : uuid ,name: name, mobile: mobileNumber, twitter: twitterAccount, instegram: instegramAccount)
        db.child("Contacts").child(myContact.Id).setValue(myContact.toDictionary()) { error, ref in
            
            if error != nil {
                print(error!.localizedDescription)
                return
            }
            let view = self.storyboard?.instantiateViewController(withIdentifier: "Home") as? ViewController
            view?.modalPresentationStyle = .fullScreen
            self.present(view!, animated: true, completion: nil)
        }
    }
    

}

class contact
{
    var Id : String
    var name : String
    var mobile : String
    var twitter : String
    var instegram : String
    
    init()
    {
        self.Id = ""
        self.name = ""
        self.twitter = ""
        self.instegram = ""
        self.mobile = ""
    }
    init(Id : String ,name: String, mobile: String, twitter: String, instegram: String)
    {
        self.instegram = instegram
        self.name = name
        self.twitter = twitter
        self.mobile = mobile
        self.Id = Id
    }
    func toDictionary() ->[String:String]
    {
        return ["Id" : self.Id,
                "name" : self.name,
                "mobile" : self.mobile,
                "twitter" : self.twitter,
                "instegram" : self.instegram
        ]
    }
}
