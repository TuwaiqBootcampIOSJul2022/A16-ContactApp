//
//  ViewController.swift
//  ContactsApp
//
//  Created by Abdullah on 11/02/1444 AH.
//


import UIKit
import FirebaseFirestore


class ViewController: UIViewController {


    
    let db = Firestore.firestore()
    var arrays:[[String:String]] = [[:]]
    var name:String?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
       

    }
   
}
