//
//  viewController2ViewController.swift
//  login
//
//  Created by Mansour Al-Dossery on 07/09/2022.
//
import UIKit
import Firebase

class viewController2ViewController: UIViewController {
    let db = Firestore.firestore()

    @IBOutlet weak var search: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        readData()
    }
    let arr = ["a","b","c","d"]
    

    @IBAction func btn1(_ sender: Any) {
    }
    @IBAction func btn2(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
