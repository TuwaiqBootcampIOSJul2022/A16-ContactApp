//
//  ViewController.swift
//  login
//
//  Created by Mansour Al-Dossery on 06/09/2022.
//

import UIKit
import Firebase
import Contacts
import ContactsUI

struct person{
  let name : String
    let id :String
    let source : CNContact
    
}
class ViewController: UIViewController, UITableViewDataSource,CNContactPickerDelegate,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = models[indexPath.row].name
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let contact = models[indexPath.row].source
        let vc = CNContactViewController(for: contact)
        present(UINavigationController(rootViewController: vc), animated: true)
    }
    
    
    private let tabel : UITableView = {
     let tabel = UITableView()
        tabel.register(UITableViewCell . self
                       , forCellReuseIdentifier: "cell")
        return tabel
    }()
    
    var models = [person]()
    
    let db = Firestore.firestore()
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tabel)
        tabel.frame = view.bounds
        tabel.dataSource = self
        tabel.delegate = self
        // Do any additional setup after loading the view.
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add,
                                                            target: self, action:#selector(didTabAdd))
        readData()
        
    }
    @objc func didTabAdd(){
        let vc = CNContactPickerViewController()
        vc.delegate = self
        present(vc, animated: true)
    }
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        let name = contact.givenName + " " + contact.familyName
        let identifier = contact.identifier
        let model = person(name: name, id: identifier, source: contact)
        models.append(model)
        tabel.reloadData()
    }
//    models.append(model)

//    func saveData(){
//    db.collection("users").addDocument(data:
//    ["name":"Ruba" ,
//    "bd": "1999" ,
//    "phonNumber":"0500" ,
//     "adress": "KSA"]) { error in
//        if let e = error {
//            print(e.localizedDescription)
//        }else {
//            print("Data has been saved")
//
//        }
//    }
//    }
    
    @IBAction func loginbtn(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
        
        let email = emailTextField.text!
        let password = passwordTextField.text!
        Auth.auth().signIn(withEmail: email, password: password){ result, error in
            guard error == nil else {
                print("ERROR:\(error!.localizedDescription)")
                return
            }
            print("logged in successfuly")
            
        }
        
    }
    @IBAction func signOut(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
            
        }
    }
    // save data
    func saveData(){
    db.collection("users2").addDocument(data:
    ["name":"Ruba" ,
    "bd": "1999" ,
    "phonNumber":"0500" ,
     "adress": "KSA"]) { error in
        if let e = error {
            print(e.localizedDescription)
        }else {
            print("Data has been saved")
            
        }
    }
    }
    // read data
    func readData() {
        db.collection("order")
            .whereField("productID", isEqualTo:"C123")
            .getDocuments { querySnapshot, error in
            
            // check for errors
            guard error == nil else {return}
            
            for document in querySnapshot!.documents{
                let data = document.data()
                print(data["product"]as! String)
                
              
            }
        }
        
    }
 

    
    @IBAction func buttonPressed(_ sender: Any) {
//        saveData()
        readData()
    }
    
    
    @IBAction func `switch`(_ sender: Any) {
    }
}

