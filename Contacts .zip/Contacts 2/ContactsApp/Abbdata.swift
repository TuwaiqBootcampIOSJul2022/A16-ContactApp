//
//  Abbdata.swift
//  ContactsApp
//
//  Created by KhalidAteeq on 11/02/1444 AH.
//



import UIKit
import Firebase

class Abbdata: UIViewController {

    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var tabelView1: UITableView!
    
    var arrays:[[String:String]] = [[:]]
    let db = Firestore.firestore()
    
    var name:String?
    var email:String?
    var phoneNumber: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tabelView1.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        readData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showContact"{
            if let viewVC = segue.destination as? Data{
                viewVC.nameContact = name
                viewVC.emailContact = email
                viewVC.phoneNumberContact = phoneNumber
                
            }
        }
    }
    
    func readData(){
        db.collection("Contact").getDocuments() { (querySnapshot, err) in
            guard err == nil else {
                print("Error getting documents: \(String(describing: err?.localizedDescription))")
                return
            }
            self.arrayData.removeAll()
            for document in querySnapshot!.documents {
                let item = document.data()
                let nameDB = item["Name"] as! String
                let emailDB = item["Email"] as! String
                let numberDB = item["PhoneNumber"] as! String
                

                self.arrays.append(["Name":nameDB, "Email":emailDB, "PhoneNumber":numberDB])
            }
            print(self.arrayData)
            self.contactsTabelView.reloadData()
        }
    }
}

extension Abbdata: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrays.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
            cell.NameLabel.text = arrays[indexPath.row]["Name"]

        return cell
    }
}

extension Abbdata: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        name = arrays[indexPath.row]["Name"]
        email = arrays[indexPath.row]["Email"]
        phoneNumber = arrays[indexPath.row]["PhoneNumber"]//showContact
        performSegue(withIdentifier: "showContact", sender: nil)
    }
}
