//
//  Abb.swift.swift
//  ContactsApp
//
//  Created by KhalidAteeq on 11/02/1444 AH.
//



import UIKit
import Firebase

class Abb: UIViewController {
    
    @IBOutlet weak var viewBackground4: UIView!
    @IBOutlet weak var saveButtonOutlet: UIButton!
    
    @IBOutlet weak var nameAddField: UITextField!
    @IBOutlet weak var emailAddField: UITextField!
    @IBOutlet weak var phoneAddField: UITextField!

    
    @IBOutlet weak var messageAddLabel: UILabel!
    
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }


    @IBAction func saveButton(_ sender: Any) {
//        if nameAddField.text != "" && emailAddField.text != "" && phoneAddField.text != "" && addressAddField.text != "" {
            db.collection("Contact").addDocument(data: [
                "Name": self.nameAddField.text!,
                "Email": self.emailAddField.text!,
                "PhoneNumber": self.phoneAddField.text!,
                "Address": self.addressAddField.text!
            ]) { error in
                if let e = error{
                    self.messageAddLabel.text =  e.localizedDescription
                }else{
                    print(" ✅ ")
                    _ = self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
