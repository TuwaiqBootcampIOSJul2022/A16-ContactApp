//
//  Data.swift.swift
//  ContactsApp
//
//  Created by KhalidAteeq on 11/02/1444 AH.
//
import UIKit

class Data: UIViewController {
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var phone: UILabel!

    
    var nameContact:String?
    var emailContact:String?
    var phoneNumberContact:String?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view1.layer.cornerRadius = 16
        
        name.text = "Name: \(nameContact!)"
        email.text = "Email: \(emailContact!)"
        phone.text = "Phone Number: \(phoneNumberContact!)"
       
        
    }
    



}
